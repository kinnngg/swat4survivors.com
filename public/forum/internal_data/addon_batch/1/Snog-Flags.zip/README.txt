/*======================================================================*\
|| #################################################################### ||
|| # Country Flags by IP Address                                      # ||
|| # ---------------------------------------------------------------- # ||
|| # Copyright © 2014-2019 Snog's Mods & Add-ons                      # ||
|| # https://snogssite.com                                            # ||
|| # All Rights Reserved.                                             # ||
|| # This file may not be redistributed in whole or significant part. # ||
|| # ---------------------------------------------------------------- # ||
|| #################################################################### ||
\*======================================================================*/

This add-on displays a user's country flag based on their current IP address.

This add-on uses MaxMind's GeoLite2-Country database and MaxMind's DB Reader.

**********************
*** IMPORTANT NOTE ***
**********************
This add-on requires that BC Math be installed and configured in PHP.

To see if it is configured in PHP, look at your PHP info and look for --enable-bcmath
in the configure command area of PHP info and bcmath should appear in the configuration
section of PHP info.

If is is enabled and you get an error during install that says...
'BC Math is either not installed on your server or PHP is not compiled with it enabled.'

It means just what it says. BC Math is most likely not installed on your server and you
need to contact your host to have them install it.


* INSTALLATION *
----------------
1) Upload all of the files contained in the 'upload' folder to your forum directory.

2) Install the in the Admin->Add-ons area.

3) Go to Admin->Setup->Options->Country Flags by IP Address and set the settings the way you want them.

4) Set the 'View country flags' user group permission for the user groups you want to be able to view the flags
